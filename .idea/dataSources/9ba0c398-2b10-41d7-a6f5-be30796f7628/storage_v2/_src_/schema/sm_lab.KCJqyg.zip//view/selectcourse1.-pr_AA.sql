create view selectcourse1 as
select `t3`.`id`         AS `id`,
       `t2`.`course_id`  AS `course_id`,
       `t4`.`name`       AS `name`,
       `t2`.`teacher_id` AS `teacher_id`,
       `t1`.`name`       AS `name`,
       `t1`.`rank_name`  AS `rank_name`
from (((`sm_lab`.`teaches` `t2` left join `sm_lab`.`teacher` `t1` on ((`t1`.`id` = `t2`.`teacher_id`))) join `sm_lab`.`student` `t3`)
         left join `sm_lab`.`course` `t4` on ((`t2`.`course_id` = `t4`.`id`)));

