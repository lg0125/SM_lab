create definer = root@localhost view coursegrade as
select `t1`.`id`         AS `id`,
       `t1`.`name`       AS `name`,
       `t3`.`id`         AS `id`,
       `t3`.`name`       AS `name`,
       `t2`.`teacher_id` AS `teacher_id`,
       `t2`.`grade`      AS `grade`
from ((`sm_lab`.`student` `t1` left join `sm_lab`.`takes` `t2` on ((`t1`.`id` = `t2`.`student_id`)))
         left join `sm_lab`.`course` `t3` on ((`t2`.`course_id` = `t3`.`id`)));

