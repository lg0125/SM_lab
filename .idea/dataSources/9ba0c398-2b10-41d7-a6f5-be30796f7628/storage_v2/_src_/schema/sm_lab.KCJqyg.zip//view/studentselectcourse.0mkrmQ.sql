create definer = root@localhost view studentselectcourse as
select `t4`.`id`        AS `id`,
       `t3`.`id`        AS `id`,
       `t3`.`name`      AS `name`,
       `t1`.`id`        AS `id`,
       `t1`.`name`      AS `name`,
       `t1`.`rank_name` AS `rank_name`
from (`sm_lab`.`student` `t4`
         left join (`sm_lab`.`course` `t3` left join (`sm_lab`.`teaches` `t2` left join `sm_lab`.`teacher` `t1` on ((`t1`.`id` = `t2`.`teacher_id`))) on ((`t2`.`course_id` = `t3`.`id`)))
                   on (((0 <> 1) and (0 <> 1))));

